##patricus utils
version 3.3
copyright: C: Patricus productions,
check license for details.